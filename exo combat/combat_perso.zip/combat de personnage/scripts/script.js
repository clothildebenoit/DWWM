let min;
let max;
let randomAtq;
let randomDef;
let randomAncienAtq = -1;
min = 20;
max = 100;
class Heros {
    constructor(_nom) {

        this.nombreAleatoire = function () {

            return Math.floor(Math.random() * (max - min + 1) + min);
        }

        // while (_nom == "") {
        //     alert("Pas de nom");
        //     _nom = prompt("Saisis moi un nom");

        // }

         this.nom = _nom;
     this.vie = this.nombreAleatoire();
        this.attaque = this.nombreAleatoire();
        this.defense = this.nombreAleatoire();
     this.existe = false;
        if (this.nom != "") {
            this.existe = true;
        }

        this.afficherInfo = function () {
            console.log(`Nom : ${this.nom}, Vie : ${this.vie}, Attaque : ${this.attaque}, Défense : ${this.defense}`);

        }
        this.attaquer = function (defenseur) {

            console.log(`nouvelle attaque de: ${this.nom} sur ${defenseur.nom}`)
            if (this.attaque > defenseur.defense) {
                defenseur.vie = defenseur.vie - 10;
                console.log(`niveau de vie de ${defenseur.nom}: ${defenseur.vie}`)
            }
            if (this.attaque == defenseur.defense) {
                defenseur.vie = defenseur.vie - 5;
                console.log(`niveau de vie de ${defenseur.nom}: ${defenseur.vie}`)
            }
            if (this.attaque < defenseur.defense) {
                this.vie = this.vie - 5
                console.log(`niveau de vie de ${this.nom}: ${this.vie}`)
            }
            if (this.vie <= 0) {
                console.error(`le personnage ${this.nom} est dead.`)
                this.existe = false

            }
            if (defenseur.vie <= 0) {
                console.error(`le personnage ${defenseur.nom} est dead.`)
                defenseur.existe = false
            }

        }

    }
}

let nbrJoueur = 2;
var joueurs = new Array();
var nbrejoueurcree = 0;
var nomSaisie = '';
var perso;
while (nbrejoueurcree < nbrJoueur && nomSaisie == '') {

    nomSaisie = prompt("Saisissez un nom:");
    if (nomSaisie != '') {
        perso = new Heros(nomSaisie);
        perso.afficherInfo();
        joueurs.push(perso);
        nomSaisie = '';
        nbrejoueurcree += 1;
    }
}
// ------FONCTION RANDOM----------


function joueurAleatoire(length) {
    return Math.floor(Math.random() * length);
}

//tant qu'il reste plus d'un joueur
while (joueurs.length > 1) {
    //definit l'attaquant de façon aléatoire
    randomAtq = joueurAleatoire(joueurs.length);
    //definit le defenseur 
    randomDef = joueurAleatoire(joueurs.length);
    //verifie si l'attaquant est different de l'ancien attaquant
    if (randomAtq != randomAncienAtq) {
        //verifie si l'attaquand est different du defenseur 
        if (randomAtq != randomDef) {
            //attaque
            joueurs[randomAtq].attaquer(joueurs[randomDef])
            try {
                //si l'attaquant est mort on le supprime du tableau
                if (joueurs[randomAtq].existe == false) {
                    joueurs.splice(randomAtq, 1);
                }
                //si le defenseur est mort on le supprime du tableau
                if (joueurs[randomDef].existe == false) {
                    joueurs.splice(randomDef, 1);
                }
                //on intercepte l'erreur si la donnée du tableau n'existe plus 
            } catch (error) {

            }


            //l'attaquant devient l'ancien attaquant 
            randomAncienAtq = randomAtq;
        }
    }
    console.log(joueurs);



}
